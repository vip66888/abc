import tkinter as tk
import time

def my_function():
    print("按钮被点击了")

def handle_click(event):
    print(f"鼠标点击位置：({event.x}, {event.y})")

def do_exit(event=None):
    root.destroy()
    exit()

def f11(event=None):
    root.attributes('-fullscreen', not root.attributes('-fullscreen'))  

# 创建主窗口
root = tk.Tk()
root.title("窗口名")
root.geometry("400x300")
root.configure(bg="#000000")
root.attributes('-fullscreen', True)
root.attributes('-alpha', 0.0)

#绑定按键
root.bind("<Alt-F4>", do_exit)
root.bind("<F11>", f11)

X=root.winfo_width()
Y=root.winfo_height()

def fade_in(step=0.05):
    """让窗口从透明逐渐变为不透明"""
    alpha = 1.0
    open_time=time.time()
    while alpha >= time.time() - open_time:
        root.attributes('-alpha', (time.time() - open_time) / alpha)
        root.update()
    root.attributes('-alpha',1.0)
    root.update()

# 执行渐显
fade_in()
# 创建标签并布局
label = tk.Label(root, text="???", bg="#000000", font=("Arial", 12))
label.pack()

# 创建按钮并布局
button = tk.Button(root, text="点我", command=my_function,
                   bg="#000555", fg="#aa0055",
                   activebackground="#114514", activeforeground="#000000")
button.place(relx=0.0, rely=0.0, relwidth=0.5, relheight=0.5)

# 创建输入框并布局
entry = tk.Entry(root, width=30)
entry.pack()

# 创建滑动条并布局
scale = tk.Scale(root, from_=0, to=100, orient="horizontal")
scale.pack()

# 绑定鼠标点击事件到窗口
root.bind("<Button-1>", handle_click)

# 使用place方法放置一个额外控件
extra_label = tk.Label(root, text="我是place放置的")
extra_label.place(x=50, y=250)

# 最后进入消息循环
root.mainloop()


#pyinstaller --onefile --windowed --noconsole 
