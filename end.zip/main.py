import tkinter as tk
from tkinter import messagebox
import time
import math
import random
import json
import os
import threading
import webview
from tkinter import filedialog, colorchooser

# 强制 pywebview 使用 CEF 后端，避免 WebView2 线程冲突
os.environ['PYWEBVIEW_GUI'] = 'edgechromium'   # 替换之前的 'cef'
os.environ['CEF_DPI_SCALE'] = '1.0'   # 强制 DPI 缩放为 1

html_name=['音乐播放器','水蚀地形模拟','宇宙沙盘','图灵班图','','','','','']

# ---------------------------- 配置文件 ----------------------------
class Config:
    WINDOW_WIDTH = 960
    WINDOW_HEIGHT = 540
    BG_COLOR = "#000000"
    CANVAS_BG = "#7FA6C7"

    LAYERS = 7
    SPEED_BASE = 300
    SPEED_FACTOR = 1.5
    WAVE_FREQ_BASE = 16.0
    WAVE_DECAY = 0.9
    MAX_TERMS_NEAR = 8
    MAX_TERMS_FAR = 3
    AMPLITUDE_NEAR = 0.1
    AMPLITUDE_FAR = 0.02
    BASE_Y_NEAR = 0.5
    BASE_Y_FAR = 1.0
    COLOR_NEAR_R = 70
    COLOR_NEAR_G = 80
    COLOR_NEAR_B = 90
    COLOR_FAR_R = 200
    COLOR_FAR_G = 210
    COLOR_FAR_B = 230
    SAMPLING_STEPS = 100
    FADE_STEP = 0.05
    FADE_DELAY_MS = 20
    SCROLL_INTERVAL_MS = 33
    MAX_DT = 0.05

    ANIMATION_SPEED = 1.0
    ANIMATION_ENABLED = True
    WINDOW_OPACITY = 1.0
    CURRENT_LANG = "zh"


# ---------------------------- 多语言管理 ----------------------------
class LanguageManager:
    def __init__(self, lang_file="languages.json"):
        self.lang_file = lang_file
        self.lang_data = {}
        self.current_lang = Config.CURRENT_LANG
        self.load_languages()

    def load_languages(self):
        default_data = {
            "en": {
                "_name": "English",
                "app_title": "Smooth Mountains",
                "btn_start": "Start",
                "btn_options": "Options",
                "btn_exit": "Exit",
                "options_title": "Settings",
                "tab_animation": "Animation",
                "tab_language": "Language",
                "tab_debug": "Debug",
                "anim_speed": "Animation Speed",
                "anim_color": "Colors",
                "bg_color": "Background Color",
                "mountain_color": "Mountain Color",
                "disable_anim": "Disable Scrolling",
                "lang_select": "Select Language",
                "fixed_size": "Fixed Window Size",
                "fullscreen": "Fullscreen",
                "opacity": "Window Opacity",
                "return_btn": "Return",
                "start_grid_title": "Showcase",
                "level": "Showcase"
            },
            "zh": {
                "_name": "中文",
                "app_title": "标题",
                "btn_start": "开始",
                "btn_options": "选项",
                "btn_exit": "退出",
                "options_title": "设置",
                "tab_animation": "动画",
                "tab_language": "语言",
                "tab_debug": "调试",
                "anim_speed": "动画速度",
                "anim_color": "颜色",
                "bg_color": "背景颜色",
                "mountain_color": "山峦颜色",
                "disable_anim": "禁用滚动动画",
                "lang_select": "选择语言",
                "fixed_size": "固定窗口大小",
                "fullscreen": "全屏",
                "opacity": "窗口透明度",
                "return_btn": "返回",
                "start_grid_title": "展示栏",
                "level": " "
            }
        }

        if os.path.exists(self.lang_file):
            try:
                with open(self.lang_file, 'r', encoding='utf-8') as f:
                    self.lang_data = json.load(f)
            except:
                self.lang_data = default_data
                with open(self.lang_file, 'w', encoding='utf-8') as f:
                    json.dump(default_data, f, ensure_ascii=False, indent=2)
        else:
            self.lang_data = default_data
            with open(self.lang_file, 'w', encoding='utf-8') as f:
                json.dump(default_data, f, ensure_ascii=False, indent=2)

    def get_text(self, key):
        return self.lang_data.get(self.current_lang, self.lang_data.get("en", {})).get(key, key)

    def get_language_list(self):
        return list(self.lang_data.keys())

    def get_display_name(self, lang_code):
        return self.lang_data.get(lang_code, {}).get("_name", lang_code)

    def get_code_from_display(self, display_name):
        for code, data in self.lang_data.items():
            if data.get("_name", code) == display_name:
                return code
        return display_name


# ---------------------------- 主应用程序 ----------------------------
class MountainApp:
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("名字")
        self.width = Config.WINDOW_WIDTH
        self.height = Config.WINDOW_HEIGHT
        self.root.geometry(f"{self.width}x{self.height}")
        self.root.configure(bg=Config.BG_COLOR)

        self.canvas = tk.Canvas(self.root, bg=Config.CANVAS_BG, highlightthickness=0)
        self.canvas.place(relx=0, rely=0, relwidth=1, relheight=1)

        self.last_time = time.perf_counter()
        self.mountains = []
        self.scroll_offsets = [0.0] * Config.LAYERS
        self.layer_phase_offsets = [random.uniform(0, 2 * math.pi) for _ in range(Config.LAYERS)]
        self.scrolling_enabled = Config.ANIMATION_ENABLED

        self.lang = LanguageManager()
        self.settings_file = "settings.json"
        self.load_settings()
        Config.CURRENT_LANG = self.lang.current_lang

        self.main_menu_items = []
        self.main_menu_orig_pos = {}
        self.current_panel_items = []
        self.panel_widgets = []
        self.panel_visible = False
        self.panel_type = None
        self.current_offset_x = 0
        self.panel_offset_x = 0

        self.root.bind("<Alt-F4>", self.exit_app)
        self.root.protocol("WM_DELETE_WINDOW", self.exit_app)
        self.root.bind("<F11>", self.toggle_fullscreen)
        self.root.bind("<Escape>", self.exit_panel)
        self.root.bind("<Configure>", self.on_resize)

        self.generate_mountains()
        self.create_main_menu()
        self.raise_main_menu_above_mountains()
        self.update_ui_positions()
        self.fade_in()
        self.start_scroll()

    # ---------------------------- 设置持久化 ----------------------------
    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    saved_lang = data.get("lang", "zh")
                    if saved_lang in self.lang.get_language_list():
                        self.lang.current_lang = saved_lang
                        Config.CURRENT_LANG = saved_lang
            except:
                pass

    def save_settings(self):
        data = {"lang": self.lang.current_lang}
        with open(self.settings_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    # ---------------------------- 窗口效果 ----------------------------
    def fade_in(self, alpha=0.0):
        if alpha < 1.0:
            alpha = min(alpha + Config.FADE_STEP, 1.0)
            self.root.attributes('-alpha', alpha)
            self.root.after(Config.FADE_DELAY_MS, self.fade_in, alpha)

    def fade_out(self, alpha=1.0):
        if alpha > 0:
            alpha = max(alpha - Config.FADE_STEP, 0)
            self.root.attributes('-alpha', alpha)
            self.root.after(Config.FADE_DELAY_MS, self.fade_out, alpha)
        else:
            self.root.destroy()

    def exit_app(self, event=None):
        self.fade_out()

    def toggle_fullscreen(self, event=None):
        full = not self.root.attributes('-fullscreen')
        self.root.attributes('-fullscreen', full)

    # ---------------------------- 主菜单创建 ----------------------------
    def create_main_menu(self):
        title_id = self.canvas.create_text(0, 0, text=self.lang.get_text("app_title"),
                                           font=("微软雅黑", 24, "bold"), fill="white", anchor="n")
        start_bg = self.canvas.create_rectangle(0, 0, 0, 0, fill="#3498DB", outline="", tags="start_btn")
        start_text = self.canvas.create_text(0, 0, text=self.lang.get_text("btn_start"),
                                             font=("微软雅黑", 14), fill="white", anchor="center", tags="start_btn")
        opt_bg = self.canvas.create_rectangle(0, 0, 0, 0, fill="#2ECC71", outline="", tags="opt_btn")
        opt_text = self.canvas.create_text(0, 0, text=self.lang.get_text("btn_options"),
                                           font=("微软雅黑", 14), fill="white", anchor="center", tags="opt_btn")
        exit_bg = self.canvas.create_rectangle(0, 0, 0, 0, fill="#E74C3C", outline="", tags="exit_btn")
        exit_text = self.canvas.create_text(0, 0, text=self.lang.get_text("btn_exit"),
                                            font=("微软雅黑", 14), fill="white", anchor="center", tags="exit_btn")

        self.main_menu_items = [
            (title_id, "text"),
            (start_bg, "rect"), (start_text, "text"),
            (opt_bg, "rect"), (opt_text, "text"),
            (exit_bg, "rect"), (exit_text, "text")
        ]
        self.canvas.tag_bind("start_btn", "<Button-1>", self.on_start_click)
        self.canvas.tag_bind("opt_btn", "<Button-1>", self.on_options_click)
        self.canvas.tag_bind("exit_btn", "<Button-1>", lambda e: self.exit_app())

    def raise_main_menu_above_mountains(self):
        for item_id, _ in self.main_menu_items:
            self.canvas.tag_raise(item_id)

    def update_ui_positions(self):
        win_w = self.root.winfo_width()
        win_h = self.root.winfo_height()
        if win_w <= 1 or win_h <= 1:
            win_w, win_h = self.width, self.height

        side = min(win_w, win_h)
        square_left = (win_w - side) // 2
        square_top = (win_h - side) // 2

        title_font_size = max(12, min(48, side // 20))
        title_x = square_left + side // 2
        title_y = square_top + side * 0.08
        self.canvas.itemconfig(self.main_menu_items[0][0], font=("微软雅黑", title_font_size, "bold"))
        self.main_menu_orig_pos[self.main_menu_items[0][0]] = (title_x, title_y)

        btn_width = side // 3
        btn_height = btn_width // 4
        btn_font_size = btn_width // 10
        spacing = side * 0.05
        start_y = title_y + title_font_size * 1.2 + side * 0.05
        btn_x = square_left + (side - btn_width) // 2

        btn_positions = [
            (self.main_menu_items[1][0], self.main_menu_items[2][0], start_y),
            (self.main_menu_items[3][0], self.main_menu_items[4][0], start_y + btn_height + spacing),
            (self.main_menu_items[5][0], self.main_menu_items[6][0], start_y + 2 * (btn_height + spacing))
        ]
        for (bg_id, text_id, y) in btn_positions:
            self.main_menu_orig_pos[bg_id] = (btn_x, y, btn_x + btn_width, y + btn_height)
            self.main_menu_orig_pos[text_id] = (btn_x + btn_width // 2, y + btn_height // 2)
            self.canvas.itemconfig(text_id, font=("微软雅黑", btn_font_size))

        self.apply_main_menu_offset()

    def apply_main_menu_offset(self):
        for item_id, item_type in self.main_menu_items:
            orig = self.main_menu_orig_pos.get(item_id)
            if not orig:
                continue
            if item_type == "text":
                x, y = orig
                self.canvas.coords(item_id, x + self.current_offset_x, y)
            elif item_type == "rect":
                x1, y1, x2, y2 = orig
                self.canvas.coords(item_id, x1 + self.current_offset_x, y1, x2 + self.current_offset_x, y2)

    # ---------------------------- 面板动画与移动 ----------------------------
    def animate_main_menu(self, target_offset_x, duration=0.3, callback=None):
        start_offset = self.current_offset_x
        start_time = time.perf_counter()

        def f1(x):
            return 4 * x**3 if x <= 0.5 else 4 * (x - 1)**3 + 1

        def update():
            elapsed = time.perf_counter() - start_time
            if elapsed >= duration:
                self.current_offset_x = target_offset_x
                self.apply_main_menu_offset()
                if callback:
                    callback()
                return
            t = elapsed / duration
            new_offset = start_offset + (target_offset_x - start_offset) * f1(t)
            self.current_offset_x = new_offset
            self.apply_main_menu_offset()
            self.root.after(16, update)
        update()

    def animate_panel(self, target_offset_x, duration=0.3, callback=None):
        start_offset = self.panel_offset_x
        start_time = time.perf_counter()

        def f1(x):
            return 4 * x**3 if x <= 0.5 else 4 * (x - 1)**3 + 1

        def update():
            elapsed = time.perf_counter() - start_time
            if elapsed >= duration:
                self.panel_offset_x = target_offset_x
                self.apply_panel_offset()
                if callback:
                    callback()
                return
            t = elapsed / duration
            new_offset = start_offset + (target_offset_x - start_offset) * f1(t)
            self.panel_offset_x = new_offset
            self.apply_panel_offset()
            self.root.after(16, update)
        update()

    def apply_panel_offset(self):
        for item_id, item_type, rel_coords in self.current_panel_items:
            ox = self.panel_offset_x
            if item_type == "text":
                x, y = rel_coords
                self.canvas.coords(item_id, x + ox, y)
            elif item_type == "rect":
                x1, y1, x2, y2 = rel_coords
                self.canvas.coords(item_id, x1 + ox, y1, x2 + ox, y2)
            elif item_type == "window":
                x, y = rel_coords
                self.canvas.coords(item_id, x + ox, y)

    # ---------------------------- 面板创建与清除 ----------------------------
    def clear_panel(self, destroy_widgets=True):
        if destroy_widgets:
            for w in self.panel_widgets:
                try:
                    w.destroy()
                except:
                    pass
            self.panel_widgets.clear()
        for item_id, _, _ in self.current_panel_items:
            self.canvas.delete(item_id)
        self.current_panel_items.clear()
        self.panel_visible = False
        self.panel_type = None

    def _add_panel_item(self, item_id, item_type, rel_coords):
        self.current_panel_items.append((item_id, item_type, rel_coords))

    def show_options_panel(self):
        self.clear_panel()
        win_w = self.root.winfo_width()
        win_h = self.root.winfo_height()

        bg_id = self.canvas.create_rectangle(0, 0, win_w, win_h, fill="#000000", stipple="gray50")
        self._add_panel_item(bg_id, "rect", (0, 0, win_w, win_h))

        tab_height = 50
        tab_y = 50
        tab_width = win_w // 3
        tabs = ["tab_animation", "tab_language", "tab_debug"]
        tab_names = [self.lang.get_text(t) for t in tabs]
        for i, name in enumerate(tab_names):
            x1 = i * tab_width
            x2 = x1 + tab_width
            rect = self.canvas.create_rectangle(x1, tab_y, x2, tab_y + tab_height, fill="#444444", outline="#888888")
            text = self.canvas.create_text((x1 + x2)//2, tab_y + tab_height//2, text=name, fill="white",
                                           font=("微软雅黑", 12))
            self._add_panel_item(rect, "rect", (x1, tab_y, x2, tab_y + tab_height))
            self._add_panel_item(text, "text", ((x1 + x2)//2, tab_y + tab_height//2))
            self.canvas.tag_bind(rect, "<Button-1>", lambda e, idx=i: self.show_tab(idx))
            self.canvas.tag_bind(text, "<Button-1>", lambda e, idx=i: self.show_tab(idx))

        content_y = tab_y + tab_height + 20
        content_h = win_h - content_y - 60
        content_bg = self.canvas.create_rectangle(20, content_y, win_w-20, content_y + content_h,
                                                  fill="#2C3E50", outline="#555555")
        self._add_panel_item(content_bg, "rect", (20, content_y, win_w-20, content_y + content_h))

        self.animation_frame = self.create_animation_panel(30, content_y + 10, win_w - 60, content_h - 20)
        self.language_frame = self.create_language_panel(30, content_y + 10, win_w - 60, content_h - 20)
        self.debug_frame = self.create_debug_panel(30, content_y + 10, win_w - 60, content_h - 20)
        self.current_tab = 0
        self.show_tab(0)

        ret_btn = self.canvas.create_rectangle(20, win_h-50, 120, win_h-20, fill="#E67E22", outline="")
        ret_text = self.canvas.create_text(70, win_h-35, text=self.lang.get_text("return_btn"),
                                           fill="white", font=("微软雅黑", 12))
        self._add_panel_item(ret_btn, "rect", (20, win_h-50, 120, win_h-20))
        self._add_panel_item(ret_text, "text", (70, win_h-35))
        self.canvas.tag_bind(ret_btn, "<Button-1>", lambda e: self.close_panel())
        self.canvas.tag_bind(ret_text, "<Button-1>", lambda e: self.close_panel())

        self.panel_type = "options"
        self.panel_visible = True

    def show_start_panel(self):
        self.clear_panel()
        win_w = self.root.winfo_width()
        win_h = self.root.winfo_height()

        bg_id = self.canvas.create_rectangle(0, 0, win_w, win_h, fill="#000000", stipple="gray50")
        self._add_panel_item(bg_id, "rect", (0, 0, win_w, win_h))

        title = self.canvas.create_text(win_w//2, 40, text=self.lang.get_text("start_grid_title"),
                                        fill="white", font=("微软雅黑", 18, "bold"))
        self._add_panel_item(title, "text", (win_w//2, 40))

        rows, cols = 3, 3
        margin = 40
        grid_width = win_w - 2 * margin
        grid_height = win_h - 120
        cell_w = grid_width // cols
        cell_h = grid_height // rows
        start_x = margin
        start_y = 80
        for r in range(rows):
            for c in range(cols):
                x1 = start_x + c * cell_w
                y1 = start_y + r * cell_h
                x2 = x1 + cell_w - 10
                y2 = y1 + cell_h - 10
                rect = self.canvas.create_rectangle(x1, y1, x2, y2, fill="#3498DB", outline="white", width=2)
                num = r * cols + c + 1
                text = self.canvas.create_text((x1+x2)//2, (y1+y2)//2,
                                               text=f"{self.lang.get_text('level')} {html_name[num-1]}",
                                               fill="white", font=("微软雅黑", 12))
                self._add_panel_item(rect, "rect", (x1, y1, x2, y2))
                self._add_panel_item(text, "text", ((x1+x2)//2, (y1+y2)//2))
                self.canvas.tag_bind(rect, "<Button-1>", lambda e, n=num: self.on_level_click(n))
                self.canvas.tag_bind(text, "<Button-1>", lambda e, n=num: self.on_level_click(n))

        ret_btn = self.canvas.create_rectangle(20, win_h-50, 120, win_h-20, fill="#E67E22", outline="")
        ret_text = self.canvas.create_text(70, win_h-35, text=self.lang.get_text("return_btn"),
                                           fill="white", font=("微软雅黑", 12))
        self._add_panel_item(ret_btn, "rect", (20, win_h-50, 120, win_h-20))
        self._add_panel_item(ret_text, "text", (70, win_h-35))
        self.canvas.tag_bind(ret_btn, "<Button-1>", lambda e: self.close_panel())
        self.canvas.tag_bind(ret_text, "<Button-1>", lambda e: self.close_panel())

        self.panel_type = "start"
        self.panel_visible = True

    # ---------------------------- 核心：点击九宫格打开对应 html ----------------------------
    def on_level_click(self, level_num):
        html_file = f"{level_num}.html"
        html_path = os.path.abspath(html_file)

        if not os.path.exists(html_path):
            messagebox.showerror("错误", f"文件 {html_path} 不存在！")
            return

        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        win_width = int(screen_width * 0.8)
        win_height = int(screen_height * 0.8)

        class Api:
            def close_window(self):
                if webview.windows:
                    webview.windows[0].destroy()

        api = Api()
        self.root.withdraw()
        webview.create_window(
            f"{html_name[level_num-1]}",
            html_path,
            width=win_width,
            height=win_height,
            resizable=True,
            fullscreen=False,
            js_api=api,
            confirm_close=False
        )
        webview.start(gui='edgechromium')  # 或者 'cef'
        self.root.deiconify()

    # ---------------------------- 选项设置回调函数 ----------------------------
    def on_anim_speed_change(self, val):
        Config.ANIMATION_SPEED = float(val)

    def choose_bg_color(self):
        color = colorchooser.askcolor(title="选择背景色")[1]
        if color:
            Config.BG_COLOR = color
            self.root.configure(bg=color)

    def choose_mountain_color(self):
        color = colorchooser.askcolor(title="选择山体颜色")[1]
        if color:
            rgb = self.hex_to_rgb(color)
            Config.COLOR_NEAR_R, Config.COLOR_NEAR_G, Config.COLOR_NEAR_B = rgb
            self.generate_mountains()
            self.raise_main_menu_above_mountains()

    def hex_to_rgb(self, hex_color):
        hex_color = hex_color.lstrip('#')
        return tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))

    def toggle_animation(self, var):
        Config.ANIMATION_ENABLED = not var.get()
        self.scrolling_enabled = Config.ANIMATION_ENABLED

    def change_language(self, lang_code):
        Config.CURRENT_LANG = lang_code
        self.lang.current_lang = lang_code
        self.save_settings()
        self.refresh_ui_text()

    def change_language_display(self, display_name):
        code = self.lang.get_code_from_display(display_name)
        self.change_language(code)

    def refresh_ui_text(self):
        self.canvas.itemconfig(self.main_menu_items[0][0], text=self.lang.get_text("app_title"))
        self.canvas.itemconfig(self.main_menu_items[2][0], text=self.lang.get_text("btn_start"))
        self.canvas.itemconfig(self.main_menu_items[4][0], text=self.lang.get_text("btn_options"))
        self.canvas.itemconfig(self.main_menu_items[6][0], text=self.lang.get_text("btn_exit"))
        if self.panel_visible:
            if self.panel_type == "options":
                self.show_options_panel()
                self.show_tab(self.current_tab)
                self.panel_offset_x = 0
                self.apply_panel_offset()
            elif self.panel_type == "start":
                self.show_start_panel()
                self.panel_offset_x = 0
                self.apply_panel_offset()

    def set_fixed_size(self, var):
        self.root.resizable(not var.get(), not var.get())

    def change_opacity(self, val):
        Config.WINDOW_OPACITY = float(val)
        self.root.attributes('-alpha', Config.WINDOW_OPACITY)

    def create_animation_panel(self, base_x, base_y, width, height):
        items = []
        lbl = self.canvas.create_text(base_x, base_y + 15, text=self.lang.get_text("anim_speed")+":",
                                      anchor='w', fill="white", font=("微软雅黑", 10))
        self._add_panel_item(lbl, "text", (base_x, base_y + 15))
        items.append(lbl)

        speed_val = tk.DoubleVar(value=Config.ANIMATION_SPEED)
        slider = tk.Scale(self.root, from_=0.2, to=2.0, resolution=0.05, orient=tk.HORIZONTAL,
                          variable=speed_val, command=self.on_anim_speed_change,
                          bg="#2C3E50", fg="white", highlightthickness=0)
        slider_win = self.canvas.create_window(base_x + 150, base_y + 10, window=slider,
                                               width=width-160, height=30, anchor='nw')
        self._add_panel_item(slider_win, "window", (base_x + 150, base_y + 10))
        self.panel_widgets.append(slider)
        items.append(slider_win)

        color_y = base_y + 70
        color_lbl = self.canvas.create_text(base_x, color_y + 5, text=self.lang.get_text("anim_color")+":",
                                            anchor='w', fill="white", font=("微软雅黑", 10))
        self._add_panel_item(color_lbl, "text", (base_x, color_y + 5))
        items.append(color_lbl)

        bg_btn = tk.Button(self.root, text=self.lang.get_text("bg_color"), command=self.choose_bg_color)
        mt_btn = tk.Button(self.root, text=self.lang.get_text("mountain_color"), command=self.choose_mountain_color)
        bg_win = self.canvas.create_window(base_x + 150, color_y, window=bg_btn, anchor='nw')
        mt_win = self.canvas.create_window(base_x + 260, color_y, window=mt_btn, anchor='nw')
        self._add_panel_item(bg_win, "window", (base_x + 150, color_y))
        self._add_panel_item(mt_win, "window", (base_x + 260, color_y))
        self.panel_widgets.extend([bg_btn, mt_btn])
        items.extend([bg_win, mt_win])

        anim_var = tk.BooleanVar(value=not Config.ANIMATION_ENABLED)
        chk = tk.Checkbutton(self.root, text=self.lang.get_text("disable_anim"), variable=anim_var,
                             command=lambda: self.toggle_animation(anim_var),
                             bg="#2C3E50", fg="white", selectcolor="#2C3E50")
        chk_win = self.canvas.create_window(base_x, base_y + 120, window=chk, anchor='nw')
        self._add_panel_item(chk_win, "window", (base_x, base_y + 120))
        self.panel_widgets.append(chk)
        items.append(chk_win)
        return items

    def create_language_panel(self, base_x, base_y, width, height):
        items = []
        lang_lbl = self.canvas.create_text(base_x, base_y + 15, text=self.lang.get_text("lang_select")+":",
                                           anchor='w', fill="white", font=("微软雅黑", 10))
        self._add_panel_item(lang_lbl, "text", (base_x, base_y + 15))
        items.append(lang_lbl)

        codes = self.lang.get_language_list()
        display_names = [self.lang.get_display_name(c) for c in codes]
        self.lang_var = tk.StringVar(value=self.lang.get_display_name(self.lang.current_lang))
        lang_menu = tk.OptionMenu(self.root, self.lang_var, *display_names, command=self.change_language_display)
        lang_menu.config(bg="#34495E", fg="white", activebackground="#2C3E50")
        lang_win = self.canvas.create_window(base_x + 150, base_y + 10, window=lang_menu, anchor='nw')
        self._add_panel_item(lang_win, "window", (base_x + 150, base_y + 10))
        self.panel_widgets.append(lang_menu)
        items.append(lang_win)
        return items

    def create_debug_panel(self, base_x, base_y, width, height):
        items = []
        fixed_var = tk.BooleanVar(value=False)
        fixed_chk = tk.Checkbutton(self.root, text=self.lang.get_text("fixed_size"), variable=fixed_var,
                                   command=lambda: self.set_fixed_size(fixed_var),
                                   bg="#2C3E50", fg="white", selectcolor="#2C3E50")
        fixed_win = self.canvas.create_window(base_x, base_y + 10, window=fixed_chk, anchor='nw')
        self._add_panel_item(fixed_win, "window", (base_x, base_y + 10))
        self.panel_widgets.append(fixed_chk)
        items.append(fixed_win)

        fs_btn = tk.Button(self.root, text=self.lang.get_text("fullscreen"), command=self.toggle_fullscreen)
        fs_win = self.canvas.create_window(base_x + 200, base_y + 10, window=fs_btn, anchor='nw')
        self._add_panel_item(fs_win, "window", (base_x + 200, base_y + 10))
        self.panel_widgets.append(fs_btn)
        items.append(fs_win)

        opa_y = base_y + 60
        opa_lbl = self.canvas.create_text(base_x, opa_y + 10, text=self.lang.get_text("opacity")+":",
                                          anchor='w', fill="white", font=("微软雅黑", 10))
        self._add_panel_item(opa_lbl, "text", (base_x, opa_y + 10))
        items.append(opa_lbl)
        opa_slider = tk.Scale(self.root, from_=0.3, to=1.0, resolution=0.01, orient=tk.HORIZONTAL,
                              command=self.change_opacity, bg="#2C3E50", fg="white")
        opa_slider.set(Config.WINDOW_OPACITY)
        opa_win = self.canvas.create_window(base_x + 150, opa_y + 5, window=opa_slider,
                                            width=width-160, height=30, anchor='nw')
        self._add_panel_item(opa_win, "window", (base_x + 150, opa_y + 5))
        self.panel_widgets.append(opa_slider)
        items.append(opa_win)
        return items

    def show_tab(self, idx):
        self.current_tab = idx
        for frame in [self.animation_frame, self.language_frame, self.debug_frame]:
            for item in frame:
                self.canvas.itemconfig(item, state='hidden')
        active = [self.animation_frame, self.language_frame, self.debug_frame][idx]
        for item in active:
            self.canvas.itemconfig(item, state='normal')

    def close_panel(self):
        if not self.panel_visible:
            return
        win_w = self.root.winfo_width()
        self.animate_main_menu(0, 0.3)
        self.animate_panel(win_w, 0.3, callback=lambda: self.clear_panel())

    def on_start_click(self, event):
        if self.panel_visible:
            self.close_panel()
        else:
            self.show_start_panel()
            win_w = self.root.winfo_width()
            self.panel_offset_x = win_w
            self.apply_panel_offset()
            self.animate_main_menu(-win_w, 0.3)
            self.animate_panel(0, 0.3)

    def on_options_click(self, event):
        if self.panel_visible:
            self.close_panel()
        else:
            self.show_options_panel()
            win_w = self.root.winfo_width()
            self.panel_offset_x = win_w
            self.apply_panel_offset()
            self.animate_main_menu(-win_w, 0.3)
            self.animate_panel(0, 0.3)

    def exit_panel(self, event=None):
        if self.panel_visible:
            self.close_panel()

    # ---------------------------- 山脉相关 ----------------------------
    def on_resize(self, event=None):
        if event.widget == self.root:
            self.width = self.root.winfo_width()
            self.height = self.root.winfo_height()
            self.generate_mountains()
            self.raise_main_menu_above_mountains()
            self.update_ui_positions()
            if self.panel_visible:
                old_tab = getattr(self, 'current_tab', 0)
                if self.panel_type == "options":
                    self.show_options_panel()
                    self.show_tab(old_tab)
                    self.panel_offset_x = 0
                    self.apply_panel_offset()
                elif self.panel_type == "start":
                    self.show_start_panel()
                    self.panel_offset_x = 0
                    self.apply_panel_offset()
                self.current_offset_x = -self.width
                self.apply_main_menu_offset()

    def get_layer_param(self, layer):
        t = (layer - 1) / (Config.LAYERS - 1)
        max_terms = int(Config.MAX_TERMS_NEAR + t * (Config.MAX_TERMS_FAR - Config.MAX_TERMS_NEAR))
        max_terms = max(1, max_terms)
        amplitude = Config.AMPLITUDE_NEAR + t * (Config.AMPLITUDE_FAR - Config.AMPLITUDE_NEAR)
        base_y = Config.BASE_Y_NEAR + t * (Config.BASE_Y_FAR - Config.BASE_Y_NEAR)
        r = int(Config.COLOR_NEAR_R + t * (Config.COLOR_FAR_R - Config.COLOR_NEAR_R))
        g = int(Config.COLOR_NEAR_G + t * (Config.COLOR_FAR_G - Config.COLOR_NEAR_G))
        b = int(Config.COLOR_NEAR_B + t * (Config.COLOR_FAR_B - Config.COLOR_NEAR_B))
        return max_terms, amplitude, base_y, (r, g, b)

    def mountain_height(self, x, layer, phase_offset=0.0):
        t = x / self.height * 1.5
        max_terms, amplitude, base_y, _ = self.get_layer_param(layer)
        y = 0.0
        for n in range(1, max_terms + 1):
            freq = Config.WAVE_FREQ_BASE / (n + 1)
            amp = Config.WAVE_DECAY ** (n - 1)
            y += math.sin(t * freq + phase_offset) * amp
        result = self.height * (base_y + y * amplitude)
        return max(0, min(self.height, result))

    def compute_polygon_points(self, layer, phase_offset, scroll_x):
        step = max(1, self.width / Config.SAMPLING_STEPS)
        points = [0, self.height]
        x_screen = 0
        while x_screen <= self.width:
            global_x = x_screen + scroll_x
            y = self.mountain_height(global_x, layer, phase_offset)
            points.extend([x_screen, y])
            x_screen += step
        if points[-2] != self.width:
            y = self.mountain_height(self.width + scroll_x, layer, phase_offset)
            points.extend([self.width, y])
        points.extend([self.width, self.height])
        return points

    def generate_mountains(self):
        for poly_id, _ in self.mountains:
            self.canvas.delete(poly_id)
        self.mountains.clear()
        for idx in range(Config.LAYERS-1):
            layer = idx + 1
            _, _, _, (r, g, b) = self.get_layer_param(layer)
            color = f"#{r:02X}{g:02X}{b:02X}"
            phase = self.layer_phase_offsets[idx]
            points = self.compute_polygon_points(layer, phase, 0.0)
            poly_id = self.canvas.create_polygon(points, fill=color, outline="")
            self.mountains.append([poly_id, layer])

    def start_scroll(self):
        self.update_scroll()
        self.root.after(Config.SCROLL_INTERVAL_MS, self.start_scroll)

    def update_scroll(self):
        now = time.perf_counter()
        dt = min(now - self.last_time, Config.MAX_DT)
        if not self.scrolling_enabled:
            self.last_time = now
            return
        self.last_time = now
        speed_factor = Config.ANIMATION_SPEED
        for i, (poly_id, layer) in enumerate(self.mountains):
            speed = Config.SPEED_BASE / (Config.SPEED_FACTOR ** (Config.LAYERS - layer)) * speed_factor
            self.scroll_offsets[i] += speed * dt
            phase = self.layer_phase_offsets[layer - 1]
            points = self.compute_polygon_points(layer, phase, self.scroll_offsets[i])
            self.canvas.coords(poly_id, *points)


if __name__ == "__main__":
    app = MountainApp()
    app.root.mainloop()
