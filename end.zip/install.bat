@echo off
pip install numpy
pip install tkinterweb
pip install tkwebview2
pip install cefpython3
pip install scipy
pip list
echo --------------------------------------------------
echo                         over
echo --------------------------------------------------
pause
exit()
